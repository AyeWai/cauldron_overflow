<?php

$var = null;
$user = $var ?: 'jean.test';

echo "user : $user\n";