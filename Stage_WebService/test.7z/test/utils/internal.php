<?php

$arr = ['Cerise', 'Orange', 'Pomme'];

var_dump(count('Cerise'));