<?php

$a = 2; // number
$b = '2'; // string

var_dump($a === $b);

