
<body>

<p>
<a href="article.php">
<input type="button" value="Articles"></input>
</a>
<a href="commande.php">
<input type="button" value="Commandes"></input>
</a>
<a href="factures.php">
<input type="button" value="Factures"></input>
</a>
</p>


</body>

